

class Main {
    public static void main(String [] args) {
        try {

            ArchiverImpl arch = ArchiverImpl.getInstance();
            arch.createZipArchive("/home/nfetissow/ToZip/main.c");
            //arch.decompress("myfigs.zip");
        }
        catch (Throwable e) {
            e.printStackTrace();
        }
    }

}


