/**
 * Created by nfetissow on 10/28/14.
 */
import java.util.zip.*;


public interface Archiver {
    public String compress(String path);
    public String decompress(String path);
}


