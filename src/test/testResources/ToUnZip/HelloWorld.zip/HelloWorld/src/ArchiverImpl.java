/**
 * Created by nfetissow on 10/28/14.
 */

import java.io.*;
import java.util.zip.*;
import java.util.*;

public class ArchiverImpl implements Archiver{
    private static ArchiverImpl instance = null;
    private int BUFFER;
    private ArchiverImpl() {
        BUFFER = 2048;
    }

    public static ArchiverImpl getInstance() {
        if(instance == null) {
            instance = new ArchiverImpl();
        }
        return instance;
    }

    @Override
    public String compress(String path) {
        final int BUFFER = 2048;
        try {
            BufferedInputStream origin = null;
            FileOutputStream dest = new
                    FileOutputStream("myfigs.zip");
            ZipOutputStream out = new ZipOutputStream(new
                    BufferedOutputStream(dest));
            //out.setMethod(ZipOutputStream.DEFLATED);
            byte data[] = new byte[BUFFER];
            // get a list of files from current directory
            File f = new File(path+ ".");
            String files[] = f.list();

            for (int i=0; i<files.length; i++) {
                System.out.println("Adding: "+files[i]);
                FileInputStream fi = new
                        FileInputStream(path + files[i]);
                origin = new
                        BufferedInputStream(fi, BUFFER);
                ZipEntry entry = new ZipEntry(files[i]);
                out.putNextEntry(entry);
                int count;
                while((count = origin.read(data, 0,
                        BUFFER)) != -1) {
                    out.write(data, 0, count);
                }
                origin.close();
            }
            out.close();
        } catch(Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    @Override
    public String decompress(String path) {
        try {
            BufferedOutputStream dest = null;
            BufferedInputStream is = null;
            ZipEntry entry;
            ZipFile zipfile = new ZipFile(path);
            Enumeration e = zipfile.entries();
            while(e.hasMoreElements()) {
                entry = (ZipEntry) e.nextElement();
                System.out.println("Extracting: " +entry);
                is = new BufferedInputStream
                        (zipfile.getInputStream(entry));
                int count;
                byte data[] = new byte[BUFFER];
                FileOutputStream fos = new
                        FileOutputStream(entry.getName());
                dest = new
                        BufferedOutputStream(fos, BUFFER);
                while ((count = is.read(data, 0, BUFFER))
                        != -1) {
                    dest.write(data, 0, count);
                }
                dest.flush();
                dest.close();
                is.close();
            }
        } catch(Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    private String archiveDir(ZipOutputStream out, String path, String parent) throws Exception{
        byte data[] = new byte[BUFFER];
        File subDir = new File(path);
        if(subDir.isDirectory()) {
            String subDirList[] = subDir.list();
        }
        String subDirList[] = subDir.list();
        for(String sd: subDirList) {
            File f = new File(path + "/" + sd);
            if(f.isDirectory()) {
                archiveDir(out, path + "/" + sd, parent + "/" + sd);
            }
            else {
                FileInputStream fi = new FileInputStream(f);
                BufferedInputStream origin = new BufferedInputStream(fi, BUFFER);
                ZipEntry entry = new ZipEntry(parent + "/" + sd);
                out.putNextEntry(entry);
                int count;
                while ((count = origin.read(data, 0, BUFFER)) != -1) {
                    out.write(data, 0, count);
                    out.flush();
                }
                origin.close();
            }
        }
        return null;
    }

    public boolean createZipArchive(String srcFolder) {
        try {
            FileOutputStream dest = new FileOutputStream(new File("1.zip"));
            ZipOutputStream out = new ZipOutputStream(new BufferedOutputStream(dest));
            archiveDir(out, srcFolder, "");
            out.flush();
            out.close();
        } catch (Exception e) {
            System.out.println("createZipArchive threw exception: " + e.getMessage());
            return false;
        }
        return true;
    }
}
